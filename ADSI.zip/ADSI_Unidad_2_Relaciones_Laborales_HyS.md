# Unidad N.º 2 — Relaciones Laborales e Higiene y Seguridad en el Trabajo

Cátedra: Administración de Sistemas de Información (ADSI) — UTN, Facultad Regional Venado Tuerto. Año 2026. Transcripción completa del material original.

## Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO

Índice de Temas Introducción Relaciones Laborales. El nuevo paradigma laboral: del modelo protector clásico al modelo flexible-digital Fuentes del Derecho laboral Marco Sistémico actual Tipos de Contratos de trabajo Características de la nueva Ley de Modernización Laboral Gremio y Sindicato Conflictos Laborales Clasificación Medios de Lucha y Exteriorización Medios de Resolución de Conflictos Modelos para solucionar conflictos Ética Profesional Ley 19.587 (Higiene y Seguridad en el Trabajo) y la Ley 24.557 (Riesgos del Trabajo) Conclusión General Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO Introducción El mundo del trabajo atraviesa un proceso de transformación impulsado por la digitalización de las organizaciones, los cambios en los modelos productivos y la actualización del marco normativo laboral. En Argentina, estos cambios se reflejan en las modificaciones incorporadas a la legislación laboral, orientadas a modernizar las relaciones de trabajo, reducir la litigiosidad y generar mayor previsibilidad para empleadores y trabajadores.

En este contexto, la unidad analiza los principales aspectos que regulan las relaciones laborales, los derechos y obligaciones de las partes, y los mecanismos existentes para la resolución de conflictos. Asimismo, se abordan las modificaciones introducidas por la reforma laboral reciente, incluyendo nuevas herramientas como el fondo de cese laboral y la modernización de los procesos de registración y gestión del empleo.

El análisis se complementa con ejemplos aplicados al sector de las tecnologías de la información y la comunicación (TIC), permitiendo comprender cómo estas normativas impactan en organizaciones que operan en entornos digitales, donde el trabajo remoto, la gestión de proyectos y el uso de sistemas de información forman parte central de la actividad laboral.

Relaciones Laborales. El nuevo paradigma laboral: del modelo protector clásico al modelo flexible-digital La nueva Ley de Modernización Laboral (Ley 27.802), aprobada en Argentina el 27 de febrero de 2026, reforma la Ley de Contrato de Trabajo (N° 20.744) para flexibilizar las relaciones laborales.

Si antes el sistema estaba estructurado en torno a la estabilidad laboral, alta indemnización y multas agravadas por falta de registración; hoy el eje gira hacia:

 Previsibilidad de costos.  Reducción de litigiosidad.  Incentivo a la formalización.

 Adaptación a la economía del conocimiento.  Digitalización registral.

Para un Ingeniero en Sistemas, esto no se trata solo de derecho laboral: Impacta en el diseño Organizacional, modifica la gestión del talento digital, y condiciona la gobernanza de datos laborales.

Además, actualmente se está frente a un rediseño sistémico del trabajo:  La reforma laboral deroga integralmente la Ley N.º 27.555 de Teletrabajo. Los nuevos contratos de teletrabajo quedarán sujetos a la regulación general del trabajo, modificada por la nueva Ley de Modernización Laboral  Existe proyecto de actualización integral de la Ley 25.326 de protección de datos personales, para alinearla con estándares internacionales, a los fines de otorgar a las personas más control, transparencia y protección sobre sus datos personales, y exigir a las empresas que manejen esos datos con altos niveles de seguridad, claridad y respeto por los derechos de los usuarios Esta Unidad, debe comprenderse como un sistema integrado entre: Derecho + Tecnología + Ética + Gestión Organizacional Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO Fuentes del Derecho Laboral El contrato y la relación laboral se rigen por:

Fuente Impacto en Sistemas Ley 20.744 de Contrato de Trabajo. Base estructural Ley 27.802 de Modernización Laboral Reforma 2026 Estatutos profesionales Ej: prensa, construcción Convenios colectivos Sectoriales (IT en debate) Firmados entre sindicatos y cámaras empresariales.

Voluntad de partes Empleado - empleador Usos y costumbres Cultura organizacional Marco Sistémico actual Las relaciones laborales no se limitan al contrato de Trabajo. el vínculo laboral se construye día a día a través de:

- Cultura organizacional. -Clima laboral. -Comunicación interna. -Negociación colectiva.

-Conflictos. -Resolución institucional.  Cultura organizacional en empresas TIC Es el conjunto de valores, creencias, prácticas y formas de trabajo que caracterizan a una organización. En el sector tecnológico suele estar asociada a:

 metodologías ágiles (Scrum, Kanban),  innovación constante, Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO  horizontalidad,  trabajo por objetivos, Cómo la gestiona las TIC  Uso de plataformas colaborativas (Slack, Microsoft Teams, Notion).

 Documentación abierta en repositorios compartidos (GitHub, GitLab).  Transparencia en métricas de desempeño visibles para el equipo.

 Clima laboral Es la percepción que tienen los empleados sobre el ambiente de trabajo (confianza, liderazgo, motivación, presión).

En TIC puede verse afectado por:  trabajo remoto prolongado,  presión por entregas (“deadlines”),  sobrecarga por sprints continuos.

Cómo la gestiona las TIC  Encuestas internas automatizadas.  Indicadores de productividad en dashboards.

 Sistemas de feedback 360° digitales. Ejemplo Una empresa Tic implementa encuestas trimestrales anónimas online.

Detecta que el equipo DevOps reporta burnout por alertas 24/7. Se rediseñan los turnos de guardia usando métricas de carga de trabajo.

 Comunicación interna Es el flujo de información entre áreas, niveles jerárquicos y equipos. En empresas TIC es mayormente digital y asincrónica.

Cómo la gestiona las TIC  Slack / Teams.

 Reuniones por Zoom.  Gestión de proyectos en Jira.  Tableros Kanban virtuales.

Ejemplo Un equipo distribuido entre Córdoba, Buenos Aires y México coordina tareas vía Jira. La claridad o ambigüedad en los tickets impacta directamente en la relación laboral: mala comunicación genera conflictos técnicos y personales.

 Negociación colectiva en el sector TIC Es el proceso mediante el cual trabajadores y empleadores acuerdan condiciones laborales.

En TIC suele darse:  a nivel empresa (acuerdos internos),  vía cámaras empresariales,  en algunos casos mediante sindicatos tecnológicos.

Cómo la gestiona las TIC  Asambleas virtuales.  Votaciones digitales.  Foros internos de debate.

Ejemplo Una empresa SaaS negocia internamente un esquema híbrido 3x2 (3 días remoto, 2 presencial). La votación se realiza por plataforma interna con validación digital de identidad.

 Conflictos laborales Son desacuerdos por:  condiciones de trabajo,  evaluación de desempeño,  sobrecarga, Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO  cambios contractuales,  inequidad salarial.

En TIC suelen ser menos visibles pero más vinculados a:  métricas de productividad,  monitoreo digital,  evaluación automatizada.

Cómo la gestiona las TIC  Sistemas de seguimiento de tiempo (time tracking).  KPIs individuales.

 Evaluaciones automatizadas basadas en rendimiento. Ejemplo Un programador cuestiona su evaluación porque el sistema mide líneas de código y commits, pero no calidad técnica ni complejidad.

El conflicto surge por una métrica automatizada mal diseñada.  Resolución institucional de conflictos Mecanismos formales para resolver disputas:

 RRHH,  mediación interna,  conciliación administrativa,  justicia laboral. En el contexto actual también:

 canales éticos digitales,  plataformas de denuncia anónima,  auditorías algorítmicas.

Ejemplo Una empresa implementa un canal digital de denuncias anónimas por acoso o discriminación. Un empleado reporta microgestión excesiva vía monitoreo remoto. RRHH interviene con auditoría del sistema de tracking.

Tipos de Contratos de Trabajo  Contrato a tiempo indeterminado El contrato por tiempo indeterminado no tiene una fecha de finalización establecida y brinda al trabajador una mayor estabilidad:

 derecho a indemnización por despido injustificado,  acceso pleno a beneficios laborales.

Ejemplo TIC: Una empresa de desarrollo de software contrata a un desarrollador backend con contrato por tiempo indeterminado.

 Su relación laboral no tiene fecha de finalización.  El empleado recibe sueldo mensual, vacaciones, aportes jubilatorios, seguridad social, y todos los derechos laborales.

 Si la empresa decide desvincularlo sin justa causa, deberá pagar indemnización según la fórmula de la nueva ley.

 Contrato a tiempo parcial (part-time) Un contrato donde el trabajador se obliga a prestar servicios por un número de horas menor que la jornada completa habitual (hasta 2/3 de la jornada habitual) La remuneración se paga proporcional a las horas trabajadas.

Ejemplo TIC: Una empresa de desarrollo de software contrata un programador part-time para trabajar 20 horas semanales desarrollando módulos específicos de una app móvil, con salario proporcional al tiempo trabajado.

 Contrato a plazo fijo (determinados períodos) Un contrato por un tiempo determinado o para cumplir con una tarea específica, también conocido como contrato temporal. Máximo 5 años. Si se renueva sin causa → se transforma en indeterminado.

Ejemplo TIC: Una startup tecnológica que necesita un analista de datos por 6 meses para completar un proyecto de migración de datos, contrata mediante contrato a plazo fijo hasta finalizar esa etapa.

 Contrato eventual Contrato para cubrir necesidades temporales de personal o picos de trabajo, permitiendo relación laboral bajo dependencia pero por períodos ocasionales.

Ejemplo TIC: Durante un evento tecnológico nacional, una empresa contrata soporte técnico eventual para atender consultas de usuarios durante 3 semanas, con un contrato eventual.

 Contratos de servicios sin relación de dependencia (prestadores independientes) Aunque no se trata de contrato de trabajo tradicional, la reforma aclara y reafirma que ciertos vínculos se pueden pactar como servicios profesionales o independientes siempre que no exista subordinación típica de la relación laboral.

Este punto explícito en el proyecto permite mayor certeza jurídica a contratos fuera de la LCT.

Ejemplo TIC: Una empresa contrata a un consultor UX/UI independiente con contrato de servicios profesionales para diseñar la interfaz de una plataforma, sin relación de dependencia y con factura como prestador autónomo.

 Prestadores de plataformas digitales Según la interpretación de la reforma, los trabajadores de aplicaciones de reparto o servicios digitales pueden quedar fuera de la LCT tradicional y bajo un régimen específico que no se considera relación laboral dependiente cuando se trata de verdaderos prestadores de servicios independientes.

Ejemplo TIC: Un repartidor de comida que utiliza una app puede ser contratado como prestador independiente, definiendo sus horarios y sin estar bajo subordinación directa típica de un contrato laboral tradicional.

 Contrato por equipo (figura especial) La reforma define que, cuando un grupo de personas presta servicios bajo dependencia de un tercero a través de una entidad intermedia, se considera contrato de trabajo por equipo a cada integrante.

Ejemplo TIC: Una empresa tecnológica CloudTech SA necesita desarrollar una nueva plataforma de comercio electrónico. Para ello contrata a la consultora DevSolutions SRL, que asigna un equipo de trabajo compuesto por:

RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO Este grupo trabaja durante 8 meses en el proyecto dentro de CloudTech.

El empleador directo (la consultora) es quien debe pagar todas las obligaciones laborales. DevSolutions SRL es responsable de:

ART La empresa cliente (CloudTech SA), no paga directamente al trabajador, sino que paga el contrato de servicios a la consultora (DevSolutions SRL)  Ley de Pasantías (Ley 26.427) La nueva ley moderniza aspectos del derecho laboral en general, pero no derogó expresamente la normativa específica de pasantías, que sigue operando como un régimen particular con sus propias reglas.

La Ley 26.427 establece un marco para que estudiantes o reción egresados puedan realizar prácticas en empresas, con algunas condiciones especiales como:

 duración máxima,  contraprestación económica,  certificado de estudios,  proporcionalidad de cargas sociales reducidas,  objetivos formativos claros.

Ejemplo TIC: una empresa de servicios informáticos firma un contrato de pasantía con un estudiante de ingeniería en sistemas:

 El estudiante realiza tareas de mantenimiento de servidores y ayuda en proyectos menores como pasante.

 Recibe una beca o contraprestación menor que un salario pleno, acorde a lo que estipula la ley de pasantías (asignación estímulo. No es un salario).

 La pasantía tiene un tiempo límite (por ejemplo, 12 meses). Puede renovarse por 6 meses más (total máximo: 18 meses).

 Carga horaria máxima: 20 hs semanales.

 Requiere un tutor del lado de la empresa y de la universidad.  El objetivo principal es formativo, no reemplazar puestos laborales efectivos.

 La empresa no lo contrata con un contrato por tiempo indeterminado, sino bajo la modalidad de pasantía, regulada por la Ley 26.427.

Características de la nueva ley de modernización laboral  Periodo de prueba El período durante el cual un empleador y un trabajador pueden terminar la relación laboral sin causa y sin derecho a indemnización por antigüedad El trabajador debe estar registrado desde el inicio y tener aportes pagados, pero no se paga indemnización si se termina el vínculo en ese plazo.

El período de prueba pasa a ser de 6 meses para los contratos de trabajo por tiempo indeterminado.

Durante esos primeros 6 meses:

 el trabajador está registrado formalmente  tiene todos los derechos laborales básicos  pero el vínculo puede finalizar sin indemnización La reforma permite que los convenios colectivos amplíen el período de prueba según el tamaño de la empresa:

 Hasta 8 meses: empresas entre 6 y 100 trabajadores  Hasta 12 meses: microempresas de hasta 5 trabajadores Esto busca facilitar la contratación en pequeñas y medianas empresas.

Aunque esté “a prueba”, el trabajador: ✔ cobra salario según convenio ✔ tiene aportes jubilatorios ✔ tiene obra social ✔ tiene ART ✔ está protegido contra discriminación La única diferencia principal es que cualquiera de las partes puede terminar la relación laboral sin pagar indemnización.

Ejemplo TIC: Una empresa de software contrata a un desarrollador junior el 1 de marzo.

 El contrato es por tiempo indeterminado.  Durante los primeros 6 meses (marzo–agosto) el trabajador está en período de prueba.

Durante ese tiempo:  trabaja normalmente  cobra sueldo  tiene obra social y aportes Si en julio la empresa considera que el desempeño no es adecuado:

 Puede finalizar el contrato sin pagar indemnización. Si el trabajador continúa después del período de prueba:

 El contrato pasa a ser definitivo, y cualquier despido posterior deberá pagar indemnización.

 Nueva forma de indemnización Solo se considera la remuneración mensual normal y habitual para calcular la indemnización por despido sin causa (el aguinaldo, vacaciones y otros rubros quedan excluidos).

Ejemplo TIC: Si una empresa de ciberseguridad despide a un analista de seguridad sin causa, la indemnización se calculará solo con su sueldo mensual normal, no incluyendo otros pagos extras o beneficios. Esto aporta previsibilidad al costo laboral.

 Perdón de multas por empleo no registrado Se eliminan las multas establecidas por la Ley 24.013 para relaciones laborales no registradas o con registración defectuosa.

En su lugar, se crea un régimen de incentivos para formalizar trabajadores, donde el empleador que regularice a sus empleados no pagará sanciones, aunque sí deberá abonar diferencias salariales y previsionales correspondientes.

Ejemplo TIC: Una empresa de desarrollo de apps móviles descubre que varios colaboradores freelancers, que trabajaron varios meses sin alta formal, pueden ser dados de alta sin multas, solo abonando las diferencias de aportes y salarios.

 Banco de horas y organización del tiempo de trabajo Se introduce el mecanismo de banco de horas, por el cual el empleador y trabajador pueden acordar compensar horas extras con descansos en lugar de pagarlas directamente (siempre dentro de los límites de jornada).

Ejemplo TIC: En una empresa de servicios cloud, un equipo de DevOps acuerda con la empresa acumular horas de mayor carga en momentos de despliegues críticos y luego compensarlas con días libres, a través de un banco de horas pactado por escrito.

 Fondo de Asistencia Laboral (FAL) El objetivo es facilitar la cobertura de los costos asociados a desvinculaciones de personal, haciendo más previsible y sustentable el sistema de indemnizaciones.

Las grandes empresas aportan 1 % de las remuneraciones. MiPyMEs aportan 2,5 %. El Gobierno puede ajustar estos porcentajes con aprobación.

El fondo se aplica cuando se produce una desvinculación laboral por:  Despido sin causa  Terminación de contrato por voluntad unilateral del empleador  Causales que generan derecho a indemnización Entonces su lógica es:

 cada empresa aporta mensualmente un porcentaje de la masa salarial  ese dinero se acumula en un fondo específico para cubrir despidos  el fondo se utiliza cuando hay desvinculación laboral.

Es decir, no reemplaza completamente la indemnización, sino que la financia total o parcialmente. Si el fondo no alcanza, la empresa debe pagar la diferencia.

Ejemplo TIC: Supongamos que en un mes la nómina salarial total (suma de todos los sueldos) es $ 5.000.000.

Si “TechSolutions” está categorizada como MiPyME, aporta 2,5 %: 5.000.000 × 2,5 % = $ 125.000 al FAL ese mes.

Si fuera una empresa grande (por ejemplo, más de 250 empleados), aportaría 1 %: 5.000.000 × 1 % = $ 50.000 al FAL.

Supongamos que la empresa decide despedir sin causa a un ingeniero DevOps con 4 años de antigüedad, cuyo sueldo mensual normal es de $ 300.000. Según la nueva modalidad de indemnización (calculada solo sobre el salario normal), la indemnización sería equivalente a un mes de sueldo por año trabajado (simplificando para el ejemplo):

El fondo que la empresa acumuló con aportes mensuales facilita cubrir parte de esa indemnización cuando se agrupan múltiples desvinculaciones o incluso anticipa pagos en casos de reestructuraciones. Así, la empresa no enfrenta ese costo de forma abrupta y aislada.

 Jornadas y vacaciones más flexibles Se habilita la posibilidad de hasta 12 h diarias si hay acuerdo entre las partes. Las vacaciones pueden pactarse fuera del período tradicional (octubre-abril) y fraccionarse en bloques de mínimo 7 días.

Ejemplo TIC: Un proyecto de última entrega en una empresa de videojuegos acuerda con su equipo extender temporalmente la jornada para cumplir plazos, compensando luego con descansos.

RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO En el ámbito laboral, los términos gremio y sindicato suelen utilizarse como sinónimos en el lenguaje cotidiano, pero desde el punto de vista jurídico y organizacional no significan exactamente lo mismo.

Gremio El gremio es el conjunto de trabajadores que pertenecen a una misma actividad, profesión u oficio, y que comparten intereses laborales comunes.

 Es una realidad social o profesional.  Existe de hecho, es decir, existe aunque no esté formalmente organizado legalmente.

 Representa a las personas que realizan una misma actividad económica o laboral.

Ejemplos:  El gremio de los programadores de software.  El gremio de los docentes.

 El gremio de los camioneros. En todos estos casos hablamos del grupo de trabajadores que comparten una actividad, aunque no todos estén afiliados a una organización formal.

Sindicato El sindicato es una organización formal creada por trabajadores para representar y defender sus derechos e intereses laborales.

 Es una asociación legalmente constituida.  Existe de derecho, porque está reconocida por la legislación laboral.

 Posee personería gremial o inscripción sindical otorgada por el Estado.  Puede negociar convenios colectivos, representar trabajadores y participar en conflictos laborales.

Ejemplos en Argentina:  Sindicato de Camioneros  Unión Obrera Metalúrgica (UOM)  Unión Informática (sector IT) Estos sindicatos representan a trabajadores de un determinado sector o actividad.

Diferencia principal entre gremio y sindicato Ejemplo para entender la diferencia Supongamos el sector de desarrollo de software:

 Todos los programadores que trabajan en empresas tecnológicas forman parte del gremio de trabajadores informáticos.

 Sin embargo, no todos están afiliados a un sindicato. Si algunos de esos trabajadores se organizan y crean una asociación legal para representarlos, por ejemplo un sindicato de trabajadores informáticos, esa organización pasa a ser el sindicato del gremio.

En síntesis:  Gremio → el conjunto de trabajadores de una actividad.  Sindicato → la organización que representa a esos trabajadores.

Ejemplo aplicado al sector TIC (Tecnologías de la Información y Comunicación) Ejemplo concreto:

 En una empresa de software trabajan 120 desarrolladores, testers y analistas.  Todos ellos pertenecen al gremio de trabajadores informáticos, aunque no estén afiliados a ninguna organización.

 De esos 120 trabajadores, 40 deciden afiliarse a un sindicato del sector informático que los representa en negociaciones laborales.

En este caso:  El gremio está formado por todos los trabajadores del sector informático que realizan esa actividad.

 El sindicato es la organización formal que representa a parte o a la totalidad de esos trabajadores para defender sus derechos laborales.

De esta manera, el gremio representa la actividad profesional compartida, mientras que el sindicato representa la organización legal que defiende los intereses de esos trabajadores.

Conflictos Laborales Clasificación Los conflictos laborales pueden analizarse desde distintos criterios: cantidad de personas involucradas, tipo de reivindicación, naturaleza del conflicto y ámbito institucional.

Según el número de personas involucradas  Conflictos Individuales Son aquellos que enfrentan a un trabajador con su empleador, por una cuestión concreta vinculada a su relación laboral.

Se discuten derechos personales: salario, despido, sanción disciplinaria, categoría profesional, vacaciones, etc.

 Afecta a un solo trabajador.  Se resuelve generalmente en sede administrativa o judicial laboral.

 Puede basarse en incumplimiento contractual o legal. Ejemplo TIC: Un ingeniero DevOps es despedido sin causa y considera que la indemnización fue mal calculada. Inicia un reclamo judicial contra la empresa.

Es un conflicto individual porque involucra solo a ese trabajador y su empleador.

 Conflictos Colectivos Afectan a un grupo de trabajadores o a la totalidad del personal, generalmente representados por un sindicato o delegados.

Se relacionan con condiciones generales de trabajo, salarios, jornadas, beneficios, convenios colectivos.

 Interviene una representación sindical.  Puede derivar en huelgas o medidas de fuerza.

 Impacta en la organización completa.

Ejemplo TIC: El equipo completo de soporte técnico 24/7 de una empresa de datacenter realiza una huelga reclamando adicional salarial por trabajo nocturno.

Es colectivo porque involucra a un grupo organizado de trabajadores. Según el tipo de reivindicación  Conflictos Jurídicos (o de derecho) Se originan por la interpretación o aplicación de una norma existente (ley, contrato, convenio colectivo).

No se discute crear un nuevo derecho, sino aplicar correctamente uno ya vigente.  Se basa en una norma preexistente.

 Se resuelve por vía judicial o administrativa.  Tiene fundamento legal claro. Ejemplo TIC: Un grupo de desarrolladores reclama que la empresa no está aplicando correctamente el régimen de horas extras previsto en la Ley de Contrato de Trabajo.

El conflicto gira sobre cómo interpretar y aplicar la norma.  Conflictos de Interés (o económicos) Se producen cuando los trabajadores reclaman nuevas condiciones laborales que no están previstas actualmente.

No se discute una norma existente, sino la creación o modificación de condiciones.

 Se negocia.  Puede derivar en medidas de fuerza.  Es propio de negociación colectiva.

Ejemplo TIC: Los empleados de una empresa de software reclaman implementar modalidad 100% remoto permanente, cuando actualmente el esquema es híbrido.

No existe obligación legal de otorgarlo; buscan crear un nuevo beneficio.

Según la naturaleza del conflicto  Conflictos Obrero-Patronales Se producen entre trabajadores y empleador, ya sea individual o colectivamente.

Son los más frecuentes en el ámbito laboral. Ejemplo TIC: Un equipo de desarrolladores reclama que la empresa redujo unilateralmente un bono por cumplimiento de objetivos.

El conflicto enfrenta directamente a empleados vs. empresa.  Conflictos Intersindicales Se generan entre dos o más sindicatos, por cuestiones de representación o encuadramiento sindical.

 Discuten qué sindicato representa a los trabajadores.  Puede afectar negociación colectiva.

Ejemplo TIC: Dos sindicatos discuten quién debe representar a los trabajadores de una empresa de software: uno del sector informático y otro del sector comercio.

El conflicto no es contra el empleador, sino entre organizaciones sindicales.  Conflictos con el Estado Se producen entre trabajadores o empleadores y organismos estatales.

Pueden involucrar inspecciones, regulaciones, sanciones administrativas o políticas públicas laborales.

Ejemplo TIC: Una empresa tecnológica es sancionada por un organismo estatal por supuesta falta de registración de empleados remotos ante la Agencia de Recaudación y Control Aduanero.

La empresa impugna la sanción administrativa. El conflicto es empresa vs. Estado.

Otras clasificaciones relevantes  Conflictos Interpersonales Surgen entre trabajadores dentro de la organización o entre empleado y superior jerárquico, sin necesariamente involucrar cuestiones legales formales.

Discriminación o acoso Ejemplo TIC: Un project manager tiene conflictos constantes con un programador senior por diferencias en metodología de trabajo (Scrum vs. enfoque tradicional), generando tensiones en el equipo.

Puede escalar si afecta el rendimiento o deriva en sanciones. Conflictos interpersonales en Organizaciones Tecnológicas:

 Factores Críticos en TIC (Por qué estallan las peleas) Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO

- Interdependencia técnica: En tecnología, nadie es una isla. Si el de Backend no termina la API, el de Frontend no puede mostrar o avanzar, y el de QA no tiene qué testear. El error de uno, frena a todos, y ahí empiezan los "pases de factura".
- Metodologías ágiles (Scrum): Se basan en la transparencia total. Todos los días, en una reunión de 15 min (Daily), se tiene que decir qué se hizo. Si uno no avanza, queda expuesto frente a todos. Esa presión social genera roces constantes.
- Presión por Deadlines: El software suele “venderse” antes de estar listo.

Cuando llega la fecha de entrega y el código tiene "bugs", aumentan las presiones, la gente trabaja de más y la comunicación se vuelve cortante.

- Ambigüedad funcional: "¿Esto lo hace el desarrollador o el de infraestructura?". En sistemas complejos, a veces no está claro quién es el "responsable" de un error, y las tareas quedan en el sin resolver, porque nadie quiere sumar trabajo extra.

Nuevo factor 2026 Conflicto por reemplazo IA El conflicto ya no es solo "la IA me quita el puesto", sino:

 Junior vs. Senior: Un Senior usa GitHub, Copilot, o herramientas similares para hacer el trabajo que antes hacían tres Juniors. Esto genera tensión porque los que reción empiezan sienten que no tienen espacio para aprender.

 Desconfianza del código: Si un desarrollador usa IA para escribir código rápido, y ese código falla, el resto del equipo se enoja porque "lo hizo el robot y ahora lo tienen que arreglar entre todos".

Medios de Lucha y Exteriorización  Paro Interrupción temporal de las tareas. Suele ser por un tiempo definido (ej. "un paro de 24 horas"). El objetivo: Presionar de forma inmediata o dar una señal de advertencia. El "paro" se siente más como un freno de mano rápido. Es una acción directa y corta  Huelga Es una medida más organizada, radical y "oficial". El objetivo: Lograr un cambio de fondo, como un nuevo contrato colectivo o mejores condiciones de seguridad.

Suele ser el "último recurso" cuando ya no hay más diálogo. Es un proceso legal y profundo Antes: En un paro o huelga, era común que los trabajadores se pararan en la puerta de la fábrica para que nadie entrara.

Ahora: Con la reforma, si un trabajador impide el ingreso de otros empleados o de mercadería, esto puede ser considerado una "injuria laboral grave" y es motivo de despido con causa (sin indemnización).

 Trabajo a reglamento. Es una medida de fuerza muy astuta que toman los trabajadores cuando no quieren (o no pueden) ir a un paro total, pero quieren frenar la productividad de la empresa.

En lugar de faltar al trabajo, el empleado va, pero cumple estrictamente y al pie de la letra cada una de las normas de seguridad, higiene y procedimientos administrativos Si el manual dice que hay que revisar 20 puntos antes de encender una máquina, el trabajador se toma 1 hora en revisar los 20 puntos, aunque sepa que la máquina está perfecta.

El resultado: Se producen retrasos masivos, se acumulan expedientes o el transporte llega tarde, pero el trabajador no puede ser sancionado porque, técnicamente, está cumpliendo el reglamento  Lock out (patronal) El lock out patronal (o cierre patronal) es básicamente la "huelga de los dueños".

Mientras que en la huelga los empleados deciden no ir a trabajar, en el lock out es el empleador quien decide cerrar la empresa y no dejar que nadie entre.

¿Para qué sirve? Es una medida de presión del empresario para: Frenar una huelga: Si los trabajadores están haciendo paros parciales que dañan la producción, el dueño cierra todo para "forzarlos" a negociar.

Imponer condiciones: Presionar para que el sindicato acepte un contrato más barato o baje sus pretensiones de aumento.

Evitar daños: A veces se usa de forma defensiva si el dueño cree que los trabajadores van a romper máquinas o tomar la planta.

En entornos digitales puede existir:  Paro virtual. Es la versión digital de la huelga de "brazos caídos".

¿Qué es? Los trabajadores se conectan a sus puestos (log-in), pero no realizan ninguna tarea.

Cómo se ve: El empleado figura como "En línea" o "Disponible" en Slack, Teams o Zoom, pero no responde mensajes, no procesa tickets, no escribe código y no atiende llamadas.

 Desconexión coordinada. Es una medida de presión masiva basada en la invisibilidad.

¿Qué es? Un grupo grande de trabajadores decide desconectarse de los sistemas de la empresa al mismo tiempo, y por un periodo determinado.

Cómo se ve: A diferencia del paro virtual, aquí todos figuran como "Offline". Es muy común en trabajadores de plataformas, quienes coordinan para apagar la app durante las horas pico.

Efecto: Deja al usuario final sin servicio y a la empresa sin datos ni capacidad de respuesta inmediata.

 Boicot tecnológico (no válido si implica sabotaje). Es una medida más externa o de resistencia pasiva que busca afectar la reputación o el funcionamiento del sistema, pero sin romperlo (porque si rompes algo, es sabotaje y es ilegal).

¿Qué es? El rechazo colectivo a utilizar una herramienta o actualización específica que la empresa quiere imponer.

Cómo se ve: Los empleados se niegan a usar un nuevo software de monitoreo (que consideran invasivo) o inundan los canales de soporte con dudas técnicas válidas que ralentizan el sistema.

La clave legal: No es sabotaje porque no hay daño físico ni borrado de datos; simplemente se "vota con el uso" (o la falta de él) para demostrar que una tecnología no funciona sin el consentimiento del trabajador.

Negociación La negociación es un método directo entre empleador y trabajador o entre sindicatos y empleadores para llegar a un acuerdo sobre puntos de disputa sin intervención externa inicial.

 No requiere intervención de terceros.  Es voluntaria y basada en diálogo entre partes.

Se tiende a favorecer acuerdos individuales y por empresa sobre estructuras más rígidas de negociación colectiva, dándole más protagonismo a la negociación entre partes y potenciando la negociación directa con ámbitos más específicos (acuerdos por empresa o sector local) en lugar de los convenios generales tradicionales.

Ejemplo TIC: Un equipo de programadores y la dirección de una empresa de software negocian directamente una modificación de horarios de trabajo para poder integrar turnos remotos globales, llegándose a un acuerdo sin terceros.

 Mediación La mediación es un método de resolución de conflictos donde un tercero imparcial (mediador) ayuda a las partes a alcanzar un acuerdo sin sentencia. Se prioriza el diálogo y la solución consensuada.

No impone decisión. Puede ser voluntaria o, según otras normas (como la Ley de Mediación N° 26.589), ser obligatoria previa a ciertos litigios judiciales.

Sigue siendo aplicable en conflictos laborales como instancia previa a la judicialización cuando corresponde.

Ejemplo TIC: Un ingeniero de datos considera que sus horas extras no fueron bien computadas y, antes de iniciar un juicio, las partes aceptan someterse a mediación laboral para intentar un acuerdo de compensación con ayuda de un mediador profesional.

 Conciliación Es muy parecida a la mediación, pero el Conciliador tiene un rol más activo: él puede proponer soluciones (fórmulas de acuerdo).

Diferencia clave: El conciliador sugiere ideas de arreglo ("¿Qué les parece si hacen esto?"), aunque las partes aún pueden decir que no.

Ejemplo TIC: Ante una demora en la entrega de un software, un conciliador propone que la empresa de software entregue una versión beta funcional ahora y el cliente acepte un descuento en la cuota final.

 Arbitraje El arbitraje es un procedimiento donde las partes acuerdan someter su conflicto a uno o más árbitros que emiten una decisión vinculante (laudo).

Tiene efectos similares a una sentencia judicial. Es acordado (pactado) por las partes.

El arbitraje laboral puede ser utilizado cuando tanto trabajador como empleador lo aceptan para resolver controversias específicas, incluidas en convenios colectivos o pactos de partes.

Ejemplo TIC: Una empresa de ciberseguridad y un grupo de técnicos acuerdan que un conflicto sobre reparto de utilidades sea resuelto por arbitraje profesional, comprometiéndose a acatar el laudo final para evitar largos procesos judiciales.

 Vía Judicial Es la resolución del conflicto ante los tribunales laborales (Justicia Nacional del Trabajo o jurisdicción competente) cuando no se resuelve de forma previa.

El juez decide quien tiene razón aplicando la normativa. Puede generar jurisprudencia y precedentes. La reforma no elimina el acceso a la justicia laboral, aunque sí busca reducir la litigiosidad mediante reglas más claras de indemnizaciones y mecanismos de negociación.

No obstante, los conflictos que no se resuelven por negociación, mediación o arbitraje siguen pudiendo judicializarse.

Ejemplo TIC: Un equipo de desarrolladores considera que se violó la normativa sobre registro de jornada y decide iniciar una demanda ante la Justicia Nacional del Trabajo para que un tribunal interprete la aplicación correcta de las normas.

Modelos para Solucionar Conflictos Perder - Perder En este modelo, ambas partes están tan cerradas en su postura que prefieren que el otro pierda, aunque eso signifique hundirse ellos también. Suele terminar en sabotaje o juicios eternos.

Ejemplo TIC: Una empresa de software contrata a un desarrollador senior. Se pelean por el sueldo y el desarrollador, antes de irse, borra el acceso al código fuente o no entrega la documentación. La empresa pierde el proyecto y el desarrollador gana una demanda legal y una mancha negra en su reputación que le impide conseguir otro trabajo. Ambos quedan destruidos.

Negociar Aquí nadie está 100% feliz, pero el conflicto se resuelve. Ambos ceden un poco para poder seguir adelante. Es el modelo más común en la vida real.

Ejemplo TIC: Una startup de servicios de nube (Cloud) le promete a un cliente que el sistema estará listo el lunes. El equipo técnico dice que es imposible. Negocian: El lunes entregan solo las funciones básicas (el MVP) y el resto de las funciones se entregan el viernes. El cliente acepta el retraso parcial y la empresa trabaja bajo presión, pero el contrato sigue en pie.

Ganar - Ganar Es el modelo ideal. En lugar de pelearse, las partes trabajan juntas para crecer en simultáneo. Buscan una solución creativa que beneficie a todos por igual.

Este modelo maximiza la productividad. Ejemplo TIC: Una empresa de ciberseguridad encuentra una vulnerabilidad grave en el sistema de un banco. En lugar de demandar o pelear por el pago, proponen un esquema de "Bug Bounty": El banco les paga un premio por el hallazgo y les da un contrato de mantenimiento anual. El banco queda seguro (gana) y la empresa TIC consigue un cliente recurrente y prestigio (gana).

Ética profesional La ética profesional en la ingeniería de sistemas es el conjunto de principios, valores y normas de conducta que orientan el comportamiento de los profesionales que diseñan, desarrollan, implementan y administran sistemas de información y tecnologías digitales.

Su objetivo es asegurar que el trabajo del ingeniero en sistemas beneficie a la sociedad, respete los derechos de las personas, proteja la información y actúe con integridad profesional.

En disciplinas tecnológicas, la ética cobra especial importancia porque los sistemas informáticos manejan grandes volúmenes de datos, influyen en decisiones organizacionales y pueden afectar directamente la vida de las personas.

Organizaciones profesionales como la Association for Computing Machinery (ACC), y la IEEE Computer Society han desarrollado códigos de ética que sirven de referencia para los profesionales del área.

La ética profesional implica que el ingeniero debe:  Actuar con honestidad y transparencia.

 Utilizar sus conocimientos para el bienestar social.  Respetar la privacidad y seguridad de la información.

 Desarrollar sistemas confiables, seguros y de calidad.  Asumir responsabilidad por las consecuencias de los sistemas que diseña.

En otras palabras, no se trata solo de saber programar o diseñar sistemas, sino de comprender el impacto social, económico y legal de la tecnología.

Ejemplo TIC: Un ingeniero que desarrolla un sistema de análisis de datos para una empresa debe asegurarse de que no se utilicen datos personales sin consentimiento y que el sistema no discrimine a ciertos usuarios.

Deberes éticos de un ingeniero en sistemas Los deberes profesionales son las obligaciones que guían la conducta del ingeniero:

 Honestidad profesional El ingeniero debe actuar con integridad y veracidad en su trabajo.

Incluye:  No falsificar resultados de pruebas o auditorías.  No plagiar código o software sin autorización.

 Informar errores o vulnerabilidades detectadas. Ejemplo TIC: Si un sistema tiene una falla de seguridad crítica, el ingeniero debe informarlo a la organización, aunque eso retrase el proyecto.

Competencia profesional El ingeniero debe trabajar solo en áreas donde tenga la formación o experiencia adecuada.

Esto implica:  Mantenerse actualizado tecnológicamente.  No aceptar proyectos que superen sus capacidades sin apoyo adecuado.

 Aplicar buenas prácticas de ingeniería. Ejemplo TIC: un ingeniero que no conoce ciberseguridad no debería diseñar solo un sistema bancario sin apoyo de especialistas.

Protección de la información Uno de los deberes más importantes es proteger los datos y la privacidad de las personas.

Esto incluye:  Mantener la confidencialidad de la información.  Implementar controles de seguridad.

 Cumplir leyes de protección de datos. Ejemplo TIC: Un ingeniero que trabaja con datos médicos no puede compartir esa información con terceros.

Responsabilidad social Los sistemas informáticos pueden afectar a miles o millones de personas.

El ingeniero debe:  Evaluar impactos sociales y éticos de los sistemas.  Evitar desarrollar tecnologías que generen daño.

 Considerar accesibilidad e inclusión digital. Ejemplo TIC: Un algoritmo de selección laboral no debe discriminar por género, edad o condición social.

Respeto por la propiedad intelectual El ingeniero debe respetar:  licencias de software  derechos de autor  patentes tecnológicas Ejemplo TIC: No se debe usar software propietario sin licencia en un sistema corporativo.

Responsabilidades profesionales del ingeniero en sistemas Además de los deberes éticos, existen responsabilidades profesionales frente a distintos actores.

 Responsabilidad hacia la sociedad El ingeniero debe priorizar el bienestar público y la seguridad de las personas.

Ejemplo:  Sistemas de transporte  Sistemas médicos  Infraestructura crítica Un error en estos sistemas puede causar graves consecuencias sociales.

 Responsabilidad hacia la organización El ingeniero debe:  proteger los recursos tecnológicos  cumplir contratos y plazos  mantener la confidencialidad empresarial Ejemplo:

No divulgar el código fuente de un sistema propietario.

 Responsabilidad hacia los usuarios Los sistemas deben ser:  seguros  confiables  comprensibles  accesibles Ejemplo:

Un sistema bancario debe proteger las cuentas de los usuarios y evitar fraudes.  Responsabilidad hacia la profesión El ingeniero debe contribuir al prestigio y desarrollo de la profesión.

Esto implica:  compartir conocimiento  evitar prácticas desleales  respetar a otros profesionales Ejemplo:

No desacreditar injustamente el trabajo de otro ingeniero. Principios éticos clave en ingeniería de sistemas Un ingeniero en sistemas debe regirse por estos principios:

- Integridad – actuar con honestidad.
- Responsabilidad – asumir las consecuencias del trabajo realizado.
- Confidencialidad – proteger información sensible.
- Calidad profesional – desarrollar sistemas confiables.
- Respeto a la ley – cumplir normas legales y contractuales.
- Compromiso social – considerar el impacto de la tecnología en la sociedad.

Ejemplo TIC: Una empresa desarrolla una plataforma que analiza datos de empleados para decidir promociones.

Un ingeniero ético debe:  verificar que el algoritmo no genere sesgos  proteger los datos personales  asegurar la transparencia del sistema  advertir a la empresa si el sistema puede generar discriminación laboral La ética profesional en la ingeniería de sistemas garantiza que el desarrollo y uso de la tecnología se realice de forma responsable, segura y orientada al bienestar social.

Un ingeniero no solo debe poseer habilidades técnicas, sino también criterio ético para tomar decisiones que pueden afectar organizaciones, usuarios y a la sociedad en general.

Ley 19.587 (Higiene y Seguridad en el Trabajo) y la Ley 24.557 (Riesgos del Trabajo) Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO El desarrollo de las actividades laborales requiere la existencia de normas que garanticen condiciones de trabajo seguras y la protección de la salud de los trabajadores. En Argentina, dos normas fundamentales regulan esta materia:

 la Ley 19.587 de Higiene y Seguridad en el Trabajo  la Ley 24.557 de Riesgos del Trabajo Estas leyes forman parte del sistema de seguridad y salud laboral, cuyo objetivo es prevenir accidentes y enfermedades profesionales, así como garantizar la asistencia y reparación de daños cuando estos ocurren.

Aunque muchas veces se asocian a sectores industriales, estas leyes también se aplican plenamente al sector TIC, que incluye empresas de software, telecomunicaciones, centros de datos, servicios informáticos y áreas de tecnología dentro de organizaciones.

Diferencias y complementariedad entre ambas leyes Ambas leyes forman parte del sistema de seguridad laboral, pero tienen enfoques diferentes.

Ley 19.587 de Higiene y Seguridad en el Trabajo El objetivo principal de la Ley 19.587 es proteger la vida y la integridad psicofísica de los trabajadores mediante la prevención de accidentes y enfermedades laborales.

Para ello, la ley establece:  condiciones adecuadas de trabajo  normas de seguridad en instalaciones y equipos  control de factores ambientales  implementación de medidas preventivas.

En esencia, esta ley tiene un enfoque preventivo, ya que busca evitar que los accidentes o enfermedades laborales ocurran.

La ley regula diversas dimensiones relacionadas con la seguridad laboral.  Condiciones ambientales del lugar de trabajo La normativa exige que los lugares de trabajo tengan condiciones adecuadas de:

Aplicación en el sector TIC En una empresa de desarrollo de software, los programadores trabajan muchas horas frente a computadoras, por lo que es fundamental:

 iluminación adecuada para evitar fatiga visual  temperatura confortable  espacios ventilados.

Ejemplo TIC: Si una oficina tecnológica tiene iluminación deficiente, los empleados pueden sufrir:

 fatiga visual  dolores de cabeza Unidad Nº:2 – RELACIONES LABORALES E HIGIENE Y SEGURIDAD EN EL TRABAJO  disminución del rendimiento.

La empresa debe corregir estas condiciones para cumplir con la normativa.  Seguridad en instalaciones y equipamiento La ley exige que los equipos y las instalaciones cumplan con normas de seguridad para evitar accidentes.

Esto incluye:  instalaciones eléctricas seguras  mantenimiento de equipos  protección contra incendios.

Aplicación en el sector TIC En un centro de datos (data center) existen numerosos equipos electrónicos y servidores que requieren:

 sistemas eléctricos seguros  control de temperatura  sistemas de prevención de incendios.

Ejemplo TIC: Un técnico que trabaja en mantenimiento de servidores puede sufrir una descarga eléctrica si la instalación no cumple con normas de seguridad.

 Ergonomía y diseño del puesto de trabajo El diseño del puesto de trabajo debe evitar riesgos derivados de:

Aplicación en el sector TIC Muchos profesionales TIC pasan largas jornadas frente a computadoras.

Esto puede generar:

Ejemplo TIC: Un programador que utiliza una silla no ergonómica durante varios años puede desarrollar problemas en la columna vertebral.

 Capacitación y prevención La ley establece que las empresas deben capacitar a los trabajadores sobre:

Aplicación en el sector TIC Una empresa de telecomunicaciones debe capacitar a sus técnicos en:

 trabajo en altura  manipulación segura de cables y equipos. Ley 24.557 de Riesgos del Trabajo Su objetivo es:

 prevenir accidentes y enfermedades laborales  reparar los daños derivados del trabajo  garantizar asistencia médica a los trabajadores afectados.

A diferencia de la Ley 19.587, que se enfoca en la prevención, esta ley establece mecanismos de prevención y de reparación y compensación cuando ocurre un daño laboral.

La ley establece un sistema basado en la participación de las Aseguradoras de Riesgos del Trabajo (ART), que brindan cobertura a los trabajadores.

Entre los aspectos que cubre se encuentran:

 accidentes laborales  enfermedades profesionales  accidentes ocurridos en el trayecto entre el hogar y el trabajo (accidente “in itinere”).

 Prestaciones médicas Cuando ocurre un accidente laboral o enfermedad profesional, el trabajador tiene derecho a:

Ejemplo en el sector TIC Un técnico de redes que sufre una caída mientras instala cables en una empresa puede recibir:

 atención médica inmediata  tratamiento de rehabilitación.  Prestaciones económicas Si el trabajador sufre una incapacidad, el sistema prevé:

 indemnizaciones económicas  compensaciones por incapacidad parcial o total. Ejemplo en el sector TIC Un técnico de telecomunicaciones que sufre una lesión permanente puede recibir una compensación económica según el grado de incapacidad.

 Prevención de riesgos laborales Las ART también tienen funciones preventivas, como:

 asesorar a las empresas  realizar inspecciones  promover mejoras en las condiciones de trabajo.

Ejemplo en el sector TIC Una ART puede recomendar a una empresa de software:  mejorar la ergonomía de los puestos de trabajo  implementar pausas activas.

En conjunto, ambas normas buscan garantizar condiciones laborales seguras y protección para los trabajadores.

En el sector TIC, aunque los riesgos físicos suelen ser menores que en actividades industriales, existen riesgos relevantes relacionados con la ergonomía, el estrés laboral y la manipulación de infraestructura tecnológica. Por lo tanto, la correcta aplicación de estas normas permite garantizar condiciones de trabajo seguras, proteger la salud de los trabajadores y promover entornos laborales sostenibles en un sector clave para el desarrollo de la economía digital.

Ejemplos en el sector TIC Higiene y Seguridad – Riesgos del Trabajo Caso 1 – Problemas ergonómicos en programadores Situación planteada Un programador trabaja durante varios años frente a una computadora utilizando una silla no ergonómica y un escritorio mal diseñado. Con el tiempo comienza a sufrir:

Solución según la Ley 19.587 (Higiene y Seguridad) Desde el enfoque preventivo, esta ley establece que el empleador debe garantizar condiciones adecuadas de trabajo y prevenir riesgos laborales.

Por lo tanto, la empresa debe:

- Evaluar el puesto de trabajo desde el punto de vista ergonómico.
- Proveer mobiliario ergonómico adecuado, como: o sillas regulables o altura correcta de monitores o teclados y mouse adecuados.
- Implementar pausas activas o descansos periódicos.
- Capacitar a los trabajadores sobre posturas correctas frente a la computadora.

Estas medidas buscan prevenir enfermedades profesionales derivadas del trabajo sedentario y del uso prolongado de computadoras.

Solución según la Ley 24.557 (Riesgos del Trabajo) Si el trabajador ya desarrolló una enfermedad relacionada con su actividad laboral:

- Debe intervenir la ART.
- El trabajador tiene derecho a: o atención médica o tratamientos de rehabilitación o estudios diagnósticos.
- Si la lesión genera incapacidad laboral, puede corresponder: o compensación económica o indemnización según el grado de incapacidad.

Caso 2 – Accidente en técnico de telecomunicaciones Situación planteada Un técnico de redes o telecomunicaciones que instala antenas en altura sufre una caída mientras realiza su trabajo.

Solución según la Ley 19.587 La empresa tiene la obligación de prevenir este tipo de accidentes mediante medidas de seguridad.

Las medidas correctas incluyen:

- Proveer equipos de protección personal (EPP): o casco o arnés de seguridad o guantes de protección.
- Capacitar al trabajador en trabajo seguro en altura.
- Implementar procedimientos de seguridad laboral.
- Supervisar el cumplimiento de estas medidas.

Si el accidente ocurrió porque estas condiciones no estaban garantizadas, la empresa puede incurrir en responsabilidad por incumplimiento de normas de seguridad.

Solución según la Ley 24.557 En caso de accidente laboral:

- El trabajador debe ser atendido por la ART correspondiente.
- La ART debe cubrir: o atención médica inmediata o tratamientos y rehabilitación.
- Si el accidente genera incapacidad temporal: o el trabajador recibe prestaciones económicas.
- Si existe incapacidad permanente: o corresponde indemnización según el grado de incapacidad.

Caso 3 – Incidente eléctrico en centro de datos Situación planteada Un técnico que realiza mantenimiento en servidores dentro de un centro de datos recibe una descarga eléctrica debido a una falla en el sistema eléctrico.

Solución según la Ley 19.587 La empresa debe garantizar condiciones seguras en las instalaciones tecnológicas.

Las medidas preventivas obligatorias incluyen:

- Instalaciones eléctricas seguras y certificadas.
- Sistemas de protección eléctrica y puesta a tierra.
- Procedimientos de mantenimiento seguro.
- Capacitación del personal en seguridad eléctrica.

Además, el mantenimiento debe realizarse con protocolos como:  desconexión previa de equipos  señalización de riesgos.

Estas medidas buscan evitar accidentes derivados de instalaciones defectuosas. Solución según la Ley 24.557 Si ocurre el accidente:

- El trabajador debe recibir atención médica inmediata a través de la ART.
- La ART cubre: o hospitalización o tratamientos o rehabilitación.
- Si el trabajador queda con secuelas físicas, puede recibir: o compensación económica o indemnización por incapacidad.

Conclusión General El análisis desarrollado en esta unidad permite comprender cómo las relaciones laborales están experimentando un proceso de transformación impulsado por los cambios tecnológicos, la digitalización de las organizaciones y la evolución del marco normativo en Argentina. La actualización de la Ley de Contrato de Trabajo y las medidas incorporadas por la reforma laboral buscan adaptar el sistema laboral a nuevas realidades productivas, promoviendo mayor previsibilidad para las organizaciones, mecanismos más ágiles de resolución de conflictos y herramientas que reduzcan la litigiosidad.

Asimismo, la incorporación de instrumentos como el fondo de cese laboral, la modernización de los procesos de registración y la regulación de nuevas modalidades de trabajo reflejan un intento de equilibrar la protección del trabajador con la necesidad de generar entornos laborales más dinámicos y competitivos. Estos cambios también se vinculan con la creciente digitalización de la gestión del empleo, donde los sistemas de información y las tecnologías de la información y la comunicación cumplen un rol fundamental.

En este contexto, los profesionales del ámbito tecnológico adquieren una participación cada vez más relevante, no solo como trabajadores dentro de este nuevo escenario laboral, sino también como responsables del desarrollo de herramientas digitales que permiten gestionar, registrar y administrar las relaciones de trabajo en las organizaciones modernas. Comprender la interacción entre normativa laboral, gestión organizacional y tecnología resulta, por lo tanto, esencial para interpretar el funcionamiento del trabajo en la era digital.
