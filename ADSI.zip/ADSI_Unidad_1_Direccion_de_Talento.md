# Unidad N.º 1 — Dirección de Talento y Capital Humano

Cátedra: Administración de Sistemas de Información (ADSI) — UTN, Facultad Regional Venado Tuerto. Año 2026. Transcripción completa del material original.

## Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO

- Índice de Temas
- Introducción
- Tipos de Organizaciones y Procesos en TI
- Organizaciones Tradicionales de TI
- Organizaciones Agiles de TI
- Organizaciones Basadas en Proyectos
- Modelo Organico-Funcional Basado en Estrategias de Negocio
- Funciones y Perfiles en Areas de TI
- Roles Estratégicos
- Roles Tacticos
- Roles Operativos
- Perfiles Emergentes en TI
- Gestión Integral del Capital Humano
- Gerencia de Recursos Humanos: Nuevos aportes
- Propositos de las Políticas de RRHH
- Beneficios de una Política Integral
- Componentes de las Políticas de RRHH
- Subsistema 1: Provisión de Recursos Humanos
- Subsistema 2: Organización de RRHH
- Subsistema 3: Retención de RR.HH
- Subsistema 4: Desarrollo de RR.HH
- Subsistema 5: Evaluación y auditoria de RRHH

Motivación, Competencias, Desarrollo Personal y Gestión Estratégica del

- Capital Humano
- Teorias motivacionales
- 1.Jerarquia de las necesidades segdin Abraham Maslow
- 2.Teoria de los dos factores de Frederick Herzberg
- 3.Teoria de la motivación de Victor Vroom
- 4.Teoria de la Autodeterminación - Deci & Ryan
- 5.Teoria del Establecimiento de Metas — Locke & Latham
- 6.Modelo de Motivación 3.0 — Daniel Pink (Drive)
- Gestión por competencias: enfoque moderno del talento
- Desarrollo Personal y Gestión Estratégica
- FODA: herramienta estratégica
- Coaching tecnológico
- Coaching tecnológico y la Gestión del cambio
- Autoconocimiento: Base del desarrollo profesional
- Visión sistémica del capital humano
- Conclusión General

Introducción La presente unidad aborda un eje central dentro de la Administración de Sistemas de Información: la relación estratégica entre las organizaciones de Tecnologías de la Información (TI) y la gestión del capital humano. En un contexto caracterizado por transformación digital permanente, innovación acelerada y alta competitividad, la tecnología ya no cumple un rol meramente operativo, sino que se ha convertido en un habilitador clave de la estrategia del negocio. Sin embargo, su efectividad depende directamente de como se organizan las áreas de TI y de cómo se gestionan las personas que las integran.

A lo largo de la unidad se analizara la evolución de las estructuras organizacionales de TI, desde modelos tradicionales jerarquicos hasta esquemas agiles, basados en proyectos y enfoques organico-funcionales alineados con la estrategia empresarial.

Se estudiara cómo cada modelo impacta en la eficiencia operativa, la capacidad de innovación y la adaptación al cambio. En este marco, se incorporara el análisis del Strategic Alignment Model, que permite comprender como la estrategia del negocio se articula con la estrategia de IT, la estructura organizacional y la infraestructura tecnológica, evidenciando la necesidad de una alineación dinámica y bidireccional.

Asimismo, la unidad desarrollara los distintos roles y perfiles que conforman las áreas de TI —estratégicos, tácticos y operativos— junto con la aparición de perfiles emergentes vinculados a nuevas tecnologías. Este análisis permitira entender como se distribuyen responsabilidades, cómo se coordinan equipos interdisciplinarios y cómo evolucionan las trayectorias profesionales dentro del Ambito tecnológico.

Un componente esencial será la Gestión Integral del Capital Humano, entendida como un sistema compuesto por subsistemas de provisión, organización, retención, desarrollo y evaluación. Se examinaran políticas modernas de recursos humanos, técnicas de reclutamiento en el mercado IT, evaluacioén del desempeño mediante modelos como ORR y 360°, y el uso de sistemas de información y analitica de personas para la toma de decisiones estratégicas.

Finalmente, la unidad abordara la motivación y el desarrollo profesional en entornos tecnológicos, analizando teorías clasicas y contemporaneas que explican el comportamiento humano en organizaciones de conocimiento. Se estudiaran los aportes de Abraham Maslow, Frederick Herzberg, Victor Vroom y Daniel Pink, vinculando estos enfoques con la cultura agil, el aprendizaje continuo y la gestión por competencias.

En síntesis, esta unidad proporcionara una visión sistémica e integrada donde tecnología, estrategia y personas interactúan como componentes inseparables. Su propósito es comprender que la dirección de talento y capital humano no es un aspecto accesorio, sino un factor crítico para lograr organizaciones de TI eficientes, innovadoras y sostenibles en el tiempo Tipos de Organizaciones y Procesos en TI Las organizaciones de Tecnologías de la Información (TI) han evolucionado significativamente en las Últimas décadas. En sus inicios, el área de TI cumplia un rol meramente operativo, centrado en el mantenimiento de hardware, la administración de servidores y el soporte técnico básico. En la actualidad, TI se ha convertido en un actor estratégico, capaz de habilitar modelos de negocio, generar ventajas competitivas y sostener procesos críticos de la organización.

Comprender cómo se organiza un área de TI es tan importante como conocer tecnologías específicas. La estructura organizacional, los procesos y los roles determinan la eficiencia operativa, la capacidad de innovación y el alineamiento entre La organización de TI se compone de:

- Modelos de gestión - Vinculación con la estrategia del negocio Las organizaciones de TI pueden clasificarse según su estructura, su enfoque de gestión y la forma en que ejecutan sus procesos. No existe un Único modelo correcto; cada organización adopta el que mejor se adapta a su contexto, tamaño, cultura y estrategia empresarial.

- Organizaciones Tradicionales de TI
- Gerente de
- Recursos
- Humanos

Las organizaciones tradicionales de TI se caracterizan por una estructura jerarquica bien definida, con lineas claras de autoridad y responsabilidad. Cada área tiene funciones específicas y reporta a un nivel superior.

Los procesos en este modelo suelen ser:

- Lineales
- Secuenciales
- Altamente documentados
- Orientados al control y la estabilidad

Este modelo es frecuente en organizaciones grandes, con fuerte regulación o bajo nivel de cambio tecnológico, y presentan baja capacidad de adaptación.

ae eZ Empresa de manufactura con un departamento de TI interno dedicado al soporte.

Funciones principales:

- Administración de servidores
- Gestión de redes

- Soporte técnico a usuarios El coordinador de IT centraliza las decisiones y asigna tareas.

Cadena de supermercados con un área de TI dividida en: Cada sector tiene supervisores que reportan a un Gerente de TI.

- VENTAJAS DESVENTAJAS
- Control y previsibilidad Baja flexibilidad
- Claridad en roles Respuesta lenta al cambio
- Organizaciones Agiles de TI
- SCRUM PROCESS
- Product
- Owner
- serum
- Sprint
- Review
- Sprint
- Retrospective
- Product Sprint Planning Sprint Finished
- Backlog Meeting Backlog Werk
- SPRINT

Las organizaciones agiles surgen como respuesta a entornos altamente dinámicos y competitivos. Su objetivo principal es adaptarse rápidamente al cambio y entregar valor continuo al cliente.

A diferencia del modelo tradicional, la toma de decisiones es descentralizada y los equipos poseen un alto grado de autonomia.

Basadas en equipos auténomos, iterativos y orientados al cliente. Utilizan marcos como Scrum, Kanban y DevOps.

Caracteristicas Claves Estructuras flexibles Los equipos se organizan por producto o proyecto y pueden reconfigurarse.

Iteración continua El trabajo se divide en ciclos cortos llamados sprints, que permiten ajustes frecuentes.

Colaboración interdisciplinaria Los equipos integran desarrolladores, diseñadores, testers, analistas y especialistas UX.

Foco en el cliente El feedback del usuario es parte central del proceso.

Transparencia Uso de tableros Kanban, reuniones diarias (daily meetings) y métricas visibles.

Empresa de desarrollo de videojuegos:

- Feedback de jugadores en versiones beta

- Mejora continua del producto Startup de aplicaciones moviles: - Sprints de dos semanas

- Entrega continua de funcionalidades

VENTAJAS DESVENTAJAS Alta adaptabilidad Requiere madurez organizacional Mayor satisfacción del cliente Menor previsibilidad a largo plazo Detección temprana de errores Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO

- Organizaciones Basadas en Proyectos
- Director
- Acquiteeio Arsuitecto
- Desarrollador: Desarrollador
- Comprobader Com

En este modelo, la organización de TI se estructura alrededor de proyectos con objetivos, plazos y recursos definidos. Una vez finalizado el proyecto, el equipo se disuelve o se reorganiza.

Estructuradas en torno a objetivos temporales. Requieren fuerte gestión del conocimiento para evitar su pérdida al finalizar los proyectos.

Consultora de TI que implementa sistemas ERP:

- Lider de proyecto

El foco esta en cumplir alcance, tiempo y costo. Empresa minorista que implementa un sistema POS (Punto de Venta o Point of Sale) en nuevas sucursales:

- Técnicos de hardware
- Especialistas en software
- Ingenieros de redes

VENTAJAS DESVENTAJAS Enfoque claro en objetivos Menor continuidad del conocimiento

- Alta especialización Dependencia de la gestión del proyecto
- Definición y Medir, supervisar
- planificación regularmente el detallada. avance.
- VJ VJ
- Definición preliminar y Llevar acabo el pian Formalizar la
- autorización formal de gestión del aceptación
- proyecto

Modelo Organico-Funcional Basado en Estrategias de Negocio El modelo organico-funcional busca alinear la estructura de TI con los objetivos estratégicos de la empresa. TI deja de ser un área aislada y pasa a integrarse transversalmente con el negocio.

Integra TI de forma transversal con las dreas de negocio. Este modelo es clave en contextos de transformación digital y se apoya en marcos como:

- Strategic Alignment Model (SAM)
- Enterprise Architecture (TOGAF)

Caracteristicas Claves Alineación estratégica Las iniciativas de TI respaldan los objetivos corporativos.

Ejemplo: desarrollo de una plataforma de e-commerce como estrategia de expansión.

Procesos transversales Integración entre TI, marketing, ventas, finanzas y seguridad.

Ejemplo: banco que coordina TI y compliance regulatorio. Estructura flexible Capacidad de reorganizar equipos según prioridades.

Ejemplo: reorganización de TI durante la pandemia para soportar trabajo remoto.

- Strategic Alignment Model
- Business Domain IT Domain
- External Business —- iT
- Strategy Strategy
- Internal Organisation Information Systems
- Infrastructure and
- Processes
- Infrastructure and Processes

La imagen corresponde al Strategic Alignment Model (SAM) de Henderson & Venkatraman, uno de los marcos clasicos para explicar cómo se relacionan y alinean la estrategia del negocio y la estrategia de IT.

Se observa cómo una decisión estratégica del negocio se traduce, paso a paso, en tecnología operativa.

Los cuatro componentes del modelo son:

- Business Strategy (Estrategia del Negocio)

Define: - Propuesta de valor

- Posicionamiento (costos, diferenciación, innovación, etc.)

Responde a la pregunta: éQué quiere lograr la empresa y como competir?

- IT Strategy (Estrategia de IT)

Define: - Rol estratégico de IT - Capacidades digitales necesarias éComo IT va a apoyar, potenciar o transformar la estrategia del negocio?

- Organizational Infrastructure & Processes

Incluye:

- Procesos de negocio éCémo se organiza la empresa para ejecutar su estrategia?
- Information Systems Infrastructure & Processes

Incluye: - Sistemas de información

- Procesos de desarrollo, operación y soporte
- Gobierno de IT (ITIL, COBIT, DevOps, etc.) éComo IT se implementa y opera en la práctica?

La forma de entender las relaciones, es la siguiente: La flecha 1 indica que la estrategia del negocio, definida en el nivel externo, impacta directamente en la organización interna.

Qué se define en este paso:

- Procesos de negocio

Primero se define cómo compite la empresa y luego como debe organizarse para ejecutar esa estrategia.

Ejemplo - Estrategia: liderazgo en costos

- Organización: procesos estandarizados, jerarquia clara, foco en eficiencia

En este punto, IT adn no es protagonista, la prioridad es organizacional. La flecha 2 muestra que la estrategia del negocio guia la estrategia de IT.

Qué se define en este paso:

- - Rol estratégico de IT
- - Nivel de innovación esperado
- - Arquitectura tecnológica objetivo

IT no decide sola: su estrategia debe alinearse con los objetivos del negocio. Ejemplo

- Estrategia de negocio: expansión digital

- Estrategia IT: cloud, plataformas web, ciberseguridad, escalabilidad Aquí IT empieza a alinearse estratégicamente, pero todavia no se implementa nada.

La flecha 3 indica que la estrategia de IT impacta en la organización del negocio.

Qué sucede en este paso:

- Se redisefian procesos de negocio

- Se modifican roles y responsabilidades

- Se incorporan nuevas competencias digitales
- Cambia la forma de trabajar

La tecnología definida estratégicamente obliga a cambiar la organización. Ejemplo

- Estrategia IT: automatización y sistemas integrados
- Organización: procesos end-to-end, menos tareas manuales, nuevos perfiles IT

Aquí se ve claramente que IT transforma al negocio, no solo lo apoya. La flecha 4 muestra la traducción de la estrategia de IT en sistemas concretos.

Qué se define en este paso: - Sistemas de información (ERP, CRM, Bl, etc.)

- Procesos de desarrollo, operación y soporte
- Gobierno de IT

La estrategia de IT se convierte en soluciones tecnológicas reales. Ejemplo

- Estrategia IT: integración de información
- Infraestructura: ERP, bases de datos centralizadas, redes seguras

Es el paso donde la estrategia se hace operativa.

- . El negocio define qué quiere lograr
- . IT define cómo acompaiiar estratégicamente
- 3. La organización se adapta a la tecnología
- 4. La tecnología se implementa en sistemas reales

La alineación estratégica es un proceso dinámico y bidireccional, no un evento puntual.

Las flechas muestran el camino lógico para transformar estrategia en sistemas. La estrategia no empieza en IT, pero no puede ejecutarse sin IT Funciones y Perfiles en Areas de TI En un modelo moderna, los roles de TI se organizan en tres niveles:

CIO (Chief Information Officer) Responsable de la estrategia de TI y su alineación con el negocio.

Reporta al CEO. Ejemplo: liderar un plan de transformación digital para reducir costos operativos en Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO CTO (Chief Technology Officer) Enfocado en innovación tecnológica, y arquitectura tecnológica.

Trabaja junto al ClO Ejemplo: implementación de inteligencia artificial en atención al cliente.

IT Manager Coordina equipos y asegura la operación eficiente. Reporta al ClO Ejemplo: Supervisa migración de infra local, a nube hibrida.

Project Manager Gestiona proyectos de TI (tiempos, costos, riesgos). Ejemplo: implementación de CRM en una empresa de servicios.

Product Owner Define y prioriza requerimientos del producto, siendo enlace entre el equipo de desarrollo y los stakeholders.

Ejemplo: nuevas funcionalidades en e-commerce.

Otros roles Tacticos:

*[La diapositiva incluye un esquema o figura; su contenido se explica en el texto que sigue.]*

Garantiza integridad, seguridad y disponibilidad de datos. Ejemplo: Optimizar consultas SQL para mejorar el rendimiento de una plataforma de comercio electrénico.

Desarrollador Full Stack Trabaja en front-end y back-end. Ejemplo: Crear una plataforma web de reservas para una cadena hotelera.

Analista Funcional Traduce necesidades del negocio a requerimientos técnicos. Especialista en Ciberseguridad Protege sistemas y datos contra amenazas cibernéticas.

Ejemplo: Implementar firewalls y soluciones de detección de intrusos en una red corporativa Ingeniero de Redes Diseña y administra redes y VPNs.

Ejemplo: Configurar una red VPN para trabajadores remotos.

Otros Roles Operativos: - Perfiles Emergentes en TI El avance tecnológico genera nuevos roles:

- DevOps -Cientifico de Datos -Machine Learning -Arquitecto Cloud = -Especialistaen Blockchain —-Analista UX -loT -Gobernanza de Datos Cybersecurity Analysts & Devops & Platform Cloud Security Architects Engineers Blockchain Developers tor Fintech & Supply Chain Wy It ater: wy it Mates:

With growing cyber threats and Foster software delivery and Why it Matters: ‘mult-cloud adoption, security operational eficency ae vita ‘Transparency and tnst are expertise is essential. formeder enterprises. Akrviog blockchain adoption AWA Why it Matters: Wyte Mater: Why it Matters:

Businesses increasingly Pubic tus and data protection ‘The ise af oT demands

- rely on Aor automation, are crítical
- analyses, and innovation
- real-time processing and robust

- Retos Actuales en la Organización de TI Escalabilidad Ejemplo: uso de cloud para picos de trafico.

Gestión del Talento Ejemplo: retención de desarrolladores especializados. Ciberseguridad Ejemplo: protección contra ransomware en sistemas de salud, garantizando la privacidad de los pacientes.

Conclusión Comprender la organización de TI, permite entender su rol dentro de una estructura compleja, alineada con el negocio y en constante evolución. La incorporación de TIC vigentes, nuevos modelos organizativos y perfiles emergentes es clave para enfrentar los desafios actuales y futuros del sector.

Gestión Integral del Capital Humano Introducción En la actualidad, las organizaciones operan en un entorno caracterizado por alta volatilidad, incertidumbre, complejidad y ambigiiedad (entorno VUCA). En este contexto, el capital humano se convierte en un activo estratégico crítico, especialmente en organizaciones intensivas en conocimiento, como las áreas de Sistemas de Información, Tecnología y Servicios Digitales.

Desde la perspectiva de la Administración de Sistemas de Información, el capital humano no solo aporta fuerza laboral, sino conocimiento, innovación, adaptabilidad y capacidad de aprendizaje continuo, elementos fundamentales para sostener la competitividad organizacional.

Capital humano y talento humano El concepto de capital humano refiere al conjunto de conocimientos, habilidades, competencias, actitudes y valores que poseen las personas y que generan valor econdmico y estratégico para la organización.

Desde la mirada sistémica:

- Noes un recurso estatico
- Sedesarrolla, potencia o degrada según las políticas de gestión

- Se integra a los procesos, sistemas de información y cultura organizacional

- Diferencia entre talento humano y capital humano
- TALENTO HUMANO CAPITAL HUMANO
- Enfoque individual Enfoque organizacional
- Potencial de la persona Valor agregado colectivo
- Competencias personales Ventaja competitiva

Gerencia de Recursos Humanos: Nuevos aportes La Gerencia de RRHH evoluciona desde un rol administrativo hacia un rol estratégico, alineado con:

- Estrategia de negocio
- Gobierno de TI
- Gestión del cambio

RRHH como socio estratégico de TI

- Gestión de competencias digitales
- Planificación de capacidades
- Gestión del conocimiento
- Cultura DevOps y Agile

Chiavenato define las políticas de RRHH como: “Principios y directrices que orientan las decisiones relacionadas con las personas, alinedndolas con los objetivos

- organizacionales”,
- Propésitos de las Políticas de RRHH
- - Promover la Igualdad de oportunidades
- Fomentar un Clima laboral positivo
- Promover el Desarrollo de competencias
- Crear una Ventaja competitiva sostenible

Desde Sistemas, estas políticas permiten:

- Reducir rotación de perfiles IT
- Retener conocimiento crítico

Beneficios de una Política Integral Para la organización

- Menores costos de rotación
- Mejor alineación estratégica
- Fortalecimiento del employer branding (marca empleadora).

Para los colaboradores

- Proyección de carrera

Componentes de las Políticas de RRHH Los componentes, se articulan como subsistemas interdependientes:

SUBSISTEMA 1: PROVISION DE RECURSOS HUMANOS Se debe considerar: El mercado laboral IT se caracteriza por:

- Escasez de talento

Hay 3 situaciones posibles, entre la Oferta y la Demanda de Empleo:

*[La diapositiva incluye un esquema o figura; su contenido se explica en el texto que sigue.]*

El reclutamiento es un proceso estratégico que responde a:

- 1. Qué necesita la organización en términos de personas?
- 2. Qué ofrece el mercado de recursos humanos?
- 3. éQué técnicas de reclutamiento se deben emplear?

Etapas de reclutamiento

- Investigación interna de las necesidades.
- Investigación externa del mercado
- Definición de técnicas de reclutamiento

Fuentes de Reclutamiento Reclutamiento Interno: cubrir la vacante internamente, mediante:

- Planes de carrera

Reclutamiento Externo: cubrir la vacante con candidatos externos: - Selección de Personal Proceso crítico para asegurar:

- Potencial de desarrollo

Técnicas modernas

- Entrevistas por competencias
- Pruebas técnicas online
- Assessment centers (centros de evaluación, donde se evaluan las competencias, habilidades y comportamientos de los candidatos mediante simulaciones de situaciones laborales reales

SUBSISTEMA 2: ORGANIZACION DE RRHH Este subsistema responde: ¢Cómo aplicar el talento?

Su objetivo principal es asegurar que las personas adecuadas estén en los puestos adecuados, con las funciones y responsabilidades definidas, lo cual es fundamental para el éxito y la competitividad de la empresa Incluye:

- Diseño de puestos
- Evaluación del desempeño

- Integración de nuevos miembros Incluye:

- Onboarding digital (proceso de integrar a nuevos empleados utilizando herramientas y plataformas tecnológicas para hacerlo de forma remota,

- Diseño de Puestos Implica definir las tareas, responsabilidades y requisitos de cada puesto.

Se basa en Modelos:

- Clasico: Se enfoca en la eficiencia técnica y la especialización, considerando al empleado como una extensión de la máquina
- Humanista: Considera las necesidades sociales y psicológicas de los empleados, promoviendo la participación y la comunicación

- Situacional: Adapta el diseño del puesto a las características del entorno, la tecnología y las personas

- Motivacional: Busca crear puestos que generen satisfacción intrinseca, significado y responsabilidad en los empleados.

Consideraciones a tener en cuenta para IT:

- Puestos flexibles
- Roles hibridos
- Equipos agiles
- Evaluación del Desempefio

Implica definir las tareas, responsabilidades y requisitos de cada puesto, para:

- Mejora continua
- Feedback
- Decisiones de carrera
- Modelos actuales

360° Sistema integral donde un empleado es evaluado por todo su entorno laboral: jefes, pares (compañeros), subordinados y clientes. Esta técnica busca obtener una visión objetiva y completa del desempeño, fortalezas y áreas de mejora, incluyendo también la autoevaluación.

OKR (Objetivos y Resultados Clave) Consiste en definir objetivos ambiciosos (qué se quiere lograr) junto con 3-5 resultados clave medibles (cOmo se medira el éxito) para impulsar la transparencia, el enfoque y la medición de progreso en ciclos breves.

KPls digitales (Consiste en utilizar indicadores clave de rendimiento (Key Performance Indicators) cuantificables para medir la efectividad, impacto y éxito de acciones en entornos online, redes sociales y plataformas digitales).

SUBSISTEMA 3: RETENCION DE RR.HH se enfoca en mantener a los empleados motivados y comprometidos con la organización. La retención es crítica en Sistemas por:

- Costos de reemplazo
- Pérdida de conocimiento
- Responde a la pregunta: éComo retener el talento?

Elementos clave:

- Clima laboral con entorno de trabajo seguro y saludable.
- Desarrollo profesional, con oportunidades de crecimiento y desarrollo.
- Liderazgo para fomentar mentorias y guias de los equipos de trabajo

Acciones modernas de retención Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO SUBSISTEMA 4: DESARROLLO DE RR.HH Busca que los empleados puedan alcanzar su máximo potencial y contribuir al éxito de la empresa. Responde a: éCémo desarrollar el talento?

Incluye:

- Capacitación: transmitir información y desarrollar habilidades, actitudes y conocimientos.
- Desarrollo personal: crecimiento profesional del empleado a largo plazo, para asumir nuevas responsabilidades y roles.
- Desarrollo organizacional: mejorar la efectividad y la salud organizacional.

Comprende un Ciclo de:

- Detección de necesidades de capacitación.
- Diseño de programas de capacitación.
- Ejecución las actividades programadas.
- Evaluación de los resultados.

Consideraciones a tener en cuenta en IT: - E-learning. Formación virtual remota

- Bootcamps programa educativo intensivo y corto (semanas o meses) enfocado en ensefiar habilidades prácticas y específicas, usando una metodologia de

"aprender haciendo" con proyectos reales y un ritmo Claves para:

- Transferencia de conocimiento
- Planes de carrera

SUBSISTEMA 5: EVALUACION Y AUDITORIA DE RRHH El objetivo es asegurar el cumplimiento de las normativas y los objetivos organizacionales, así como identificar áreas de mejora.

Responde a: éComo asegurar el buen funcionamiento de la gestión de RRHH? Auditoria de Recursos Humanos Se encarga de evaluar y controlar y mejorar las políticas, prácticas y resultados de la gestión de recursos humanos Tipos de Auditoria - Cumplimiento: Verifica si la organización cumple con las leyes, regulaciones y políticas internas relacionadas con la gestión de personal.

- Eficiencia: Evalua si los procesos y prácticas de RRHH son eficientes en términos de costos y resultados.

- Eficacia: Analiza si las prácticas de RRHH están contribuyendo a los objetivos estratégicos de la organización.

Beneficios de la Auditoria Sistemas de Informacioén de RRHH Para recopilar y analizar datos relevantes sobre el personal, usa:

- Bases de datos

- Analitica de personas Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO Conclusión La Gestión Integral del Capital Humano, apoyada por Sistemas de Información, es hoy un factor crítico de éxito organizacional. Comprender estos subsistemas permite:

- Diseñar mejores soluciones TI

- Alinear tecnología y personas
- Participar en decisiones estratégicas
- Aportar valor real al negocio

Motivación, Competencias, Desarrollo Personal y Gestión Estratégica del Capital Humano En el campo de la Ingenieria en Sistemas de Información, existe una tendencia inicial a focalizar el análisis casi exclusivamente en la tecnología: software, hardware, redes, bases de datos, ciberseguridad o inteligencia artificial. Sin embargo, la experiencia organizacional demuestra que los sistemas fracasan o tienen éxito principalmente por las personas que los diseñan, implementan, utilizan y gestionan.

La Administración de Sistemas de Información incorpora el estudio del comportamiento humano, la motivación, las competencias, el autoconocimiento y las herramientas de desarrollo, entendiendo que el capital humano es un componente esencial del sistema organizacional.

En este contexto, analizaremos:

- La motivación humana en el trabajo

- Las principales teorías motivacionales

- La gestión por competencias
- Elanálisis estratégico (FODA)

- El coaching tecnológico - El autoconocimiento como base del desarrollo profesional en IT Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO La motivación humana: fundamentos conceptuales La motivación puede definirse como el conjunto de fuerzas internas y externas que impulsan a una persona a actuar de determinada manera, orientando su conducta hacia ciertos objetivos.

Desde una perspectiva organizacional, la motivación:

- Explica la intensidad del esfuerzo

- Determina la persistencia en el tiempo

- Influye en la calidad del desempeño
- Impacta directamente en la productividad

En entornos tecnológicos complejos, donde el trabajo intelectual predomina, la motivación es un factor crítico de desempeño.

La motivación esta profundamente ligada al sistema de cognición de cada individuo.

La cognición es la forma en que una persona: - Se percibe así misma

- Interpreta su entorno

- Construye creencias y expectativas - Dasentido alas recompensas y desafios Dos ingenieros pueden enfrentarse al mismo proyecto tecnológico y reaccionar de forma completamente distinta debido a sus diferencias cognitivas.

Importancia de la motivación en organizaciones tecnológicas En organizaciones de base tecnológica, la motivación incide en:

- Resolución de problemas
- Retención del talento IT

La desmotivación, en cambio, genera:

- Rotación de personal
- Pérdida de conocimiento organizacional

Teorias motivacionales A ccontinuación, analizaremos algunas teorías de Motivación:

1.Jerarquia de las necesidades según Abraham Maslow Maslow propone que las necesidades humanas se organizan en una estructura jerarquica, representada comuinmente como una piramide.

Niveles de la jerarquia:

- 2. Necesidades de seguridad
- 4. Necesidades de estima
- 5. Necesidades de autorrealización
- Necesidad de autorrealización

Desarrollo del potencial. Necesidad de autoestima Reconocimiento, confianza, respeto, éxito.

Necesidades sociales Desarrollo afectivo, asociación, aceptación, afecto, intimidad sexual.

Alimentación, mantenimiento de salud, /~ SY respiración, descanso, sexo. La motivación surge cuando una necesidad no satisfecha impulsa a la acción.

Aplicación de Maslow al ambito de Sistemas de Información:

- Salario, condiciones básicas
- Seguridad Estabilidad laboral, contratos
- | Sociales | Trabajo en equipo, metodologias agiles
- | estima | Reconocimiento técnico, certificaciones
- Autorrealización —_| Innovación, liderazgo tecnológico

Inicialmente, suelen predominar la seguridad y el aprendizaje, mientras que en perfiles senior cobra mayor relevancia la autorrealización profesional.

Críticas y aportes actuales a la teoría de Maslow Desde una visión moderna: - Las necesidades no siempre se satisfacen de forma estrictamente secuencial

- Enentornos IT, la autorrealización puede ser prioritaria aun sin plena seguridad

- Las diferencias culturales influyen en la jerarquia de necesidades Aun así, Maslow sigue siendo una base conceptual fundamental.

2.Teoria de los dos factores de Frederick Herzberg Herzberg distingue entre: Esta teoría introduce una diferencia clave entre satisfacción e insatisfacción laboral.

Factores higiénicos Se relacionan con el contexto del trabajo: - Políticas de la empresa Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO Su ausencia genera insatisfacción, pero su presencia no motiva por si sola.

Factores motivacionales Se relacionan con el contenido del puesto: Estos factores son los que generan verdadera motivación.

Factores motivacionales () Maxima satisfaccin (neutralidad) Maxima insatisfacción — (-) Factores higiénicos (4) Ninguna insatisfacción Teoria de los dos factores: la satisfacción y la insatisfacción como dos continuos separados.

Herzberg aplicado a entornos IT En proyectos de software:

- Un buen salario evita conflictos
- Pero los desafios técnicos motivan

- Laautonomia y el aprendizaje continuo son claves Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO 3.Teoria de la motivación de Victor Vroom Vroom plantea que la motivación depende de expectativas racionales sobre los resultados del esfuerzo, que tiene cada individuo. Es decir, no todos los empleados responderan igual ante los mismos incentivos.

Introduce el modelo: Componentes del modelo de Vroom

- Expectativa: esfuerzo > desempeño
- Instrumentalidad: desempeño > recompensa
- Valencia: valor personal de la recompensa

La motivación es el resultado de la combinación de los tres factores. Cada persona evalúa estos factores de forma distinta según sus valores, metas y experiencias. Por ejemplo, algunos empleados podrian estar altamente motivados por un bono econémico, mientras que otros preferirian más tiempo libre o reconocimiento social.

Ejemplos prácticos en Sistemas de Información Un ingeniero se motivara si:

- Cree que puede resolver el problema técnico
- Confia en que su esfuerzo será reconocido
- Valora la recompensa (dinero, tiempo libre, aprendizaje)

A continuación, se agregan 3 teorías contempordneas para considerar en la Administración de Sistemas de Información:

4.Teoria de la Autodeterminación — Deci & Ryan Enfoque general Esta teoría sostiene que la motivación humana es más fuerte y sostenible cuando se basa en motivación intrinseca, es decir, cuando la persona realiza una actividad por interés, disfrute o sentido personal, y no solo por recompensas externas.

La teoría identifica tres necesidades universales: Sentir que se tiene control sobre las propias decisiones.

Sentirse eficaz, capaz y en crecimiento. Sentirse conectado con otros. Aplicación en Sistemas de Información

- Autonomia: libertad para decidir cómo resolver un problema técnico
- Competencia: aprendizaje continuo, certificaciones, desafios técnicos

- Relación: trabajo colaborativo, equipos agiles Unidad N21 - DIRECCION DE TALENTO Y CAPITAL HUMANO Aporte clave Explica por qué los incentivos econémicos no siempre generan compromiso en profesionales IT.

5.Teoria del Establecimiento de Metas — Locke & Latham Enfoque general Esta teoría plantea que la motivación aumenta cuando las personas trabajan con metas claras, específicas y desafiantes, siempre que sean aceptadas y comprendidas.

Caracteristicas de las metas efectivas

- Desafiantes pero alcanzables
- Con feedback frecuente

Aplicación en entornos tecnológicos

- Metas de sprint (Scrum)

- KPls técnicos (calidad, performance, entregas) Aporte clave Conecta directamente motivación + desempeño + resultados, muy utilizada en gestión agil y DevOps.

6.Modelo de Motivación 3.0 — Daniel Pink (Drive) Enfoque general Daniel Pink propone que, en trabajos complejos e intelectuales (como los tecnológicos), los incentivos tradicionales pierden efectividad, y la motivación se basa en tres pilares:

- 1. Autonomia — decidir como, cuando y con quién trabajar
- 2. Maestria — deseo de mejorar continuamente
- 3. Propdsito — sentido y significado del trabajo
- Aplicación en IT
- - Autonomia: trabajo remoto, flexibilidad
- - Maestria: aprendizaje continuo, innovación
- Propdsito: impacto social, proyectos con sentido

Aporte clave Es especialmente relevante para ingenieros, desarrolladores y profesionales del conocimiento.

Comparación integrada de teorías motivacionales

- Maslow y Herzberg explican las bases de la motivación.

- Vroom explica la decisión racional de esforzarse.

- Autodeterminación y Pink explican la motivación intrinseca en trabajos de conocimiento.

- Locke conecta motivación con resultados medibles, clave en metodologias agiles.

En organizaciones tecnológicas modernas, la motivación más efectiva surge de:

- Reconocimiento del valor profesional

Gestión por competencias: enfoque moderno del talento La gestión por competencias se centra en lo que una persona sabe hacer, cómo lo hace y en qué contexto. Se centra en identificar, desarrollar y evaluar las habilidades y conocimientos específicos que los empleados necesitan para desempeñar sus roles de manera efectiva.

Permite:

- Diseñar planes de carrera

Tipos de competencias Técnicas: Especificas del puesto, como Lenguajes, redes, bases de datos, cloud, ciberseguridad.

Genéricas: Aplicables a varios roles, como Comunicación, trabajo en equipo, pensamiento crítico.

Directivas: Propias de lideres, para la toma de decisiones, gestión de conflictos, como Liderazgo, gestión del cambio, visión estratégica.

Competencias y niveles organizacionales

- Nivel operativo: desarrolladores, QA, soporte
- Nivel táctico: lideres técnicos, Scrum Masters
- Nivel estratégico: ClO, CTO, gerentes de TI

Desarrollo Personal y Gestión Estratégica FODA: herramienta estratégica El FODA permite analizar factores internos y externos para la toma de decisiones estratégicas. El objetivo es Proporcionar un diagnéstico claro que fácilite la toma de decisiones estratégicas Analiza:

- Fortalezas: Aspectos internos positivos que diferencian y benefician a la organización.

- Oportunidades: Factores externos que pueden aprovecharse para el crecimiento.

- Debilidades: Aspectos internos que limitan el desempeño.
- Amenazas: Factores externos que pueden afectar negativamente.

Aplicación del FODA en IT Ejemplo personal u organizacional:

- Fortalezas: conocimiento técnico

- Debilidades: falta de experiencia

- Oportunidades: demanda IT
- Amenazas: obsolescencia tecnológica

Ejemplo práctico: Una empresa de tecnología realiza un FODA y descubre que su fortaleza es la innovación, pero su debilidad es la falta de financiamiento. Así, desarrolla una estrategia para buscar inversionistas y potenciar su crecimiento.

Coaching Tecnológico Su Objetivo, es facilitar la integración de la tecnología en procesos laborales, El Coaching Tecnológico acompajia procesos de:

- Adopción de nuevas tecnologías
- Desarrollo de competencias digitales

Coaching Tecnológico y la Gestión del Cambio Reduce:

- Resistencia al cambio

- Fracaso de proyectos tecnológicos

- Brechas de conocimiento

Es clave en entornos de innovación constante. Ejemplo práctico: Una empresa que implementa inteligencia artificial en sus procesos recibe Coaching Tecnológico para capacitar a su equipo y optimizar el uso de la nueva tecnología.

- Empresas: Implementación de automatización y digitalización.
- Educación: Capacitación docente en herramientas digitales.
- Salud: Uso de tecnología en telemedicina y registros electrénicos.
- Emprendedores: Formación en comercio electrénico y marketing digital.

Autoconocimiento: Base del desarrollo profesional El autoconocimiento es el proceso de exploración y comprensión de uno mismo.

Implica reconocer nuestras emociones, pensamientos, fortalezas, debilidades, valores y creencias para mejorar nuestra toma de decisiones y bienestar.

El autoconocimiento permite comprender: En sistemas permite:

- Mejorar habilidades blandas
- Adaptarse al cambio tecnológico

Herramientas de autoconocimiento - Tests de personalidad (MBTI, DISC, Eneagrama)

- Coaching para un enfoque guiado
- Mindfulness para la autoconciencia emocional.

Visión sistémica del capital humano Las personas, la tecnología y los procesos forman un sistema interdependiente. No se puede optimizar uno sin considerar los otros.

La motivación, las competencias, el análisis estratégico, el coaching tecnológico y el autoconocimiento constituyen pilares esenciales para la gestión del capital humano en organizaciones tecnológicas.

Para el Ingeniero en Sistemas, dominar estos conceptos no solo mejora su desempeño técnico, sino que lo prepara para crecer profesionalmente, liderar equipos y generar valor sostenible en un entorno tecnológico dinámico y altamente competitivo.

Conclusión General La Unidad 1 permitié comprender que la Administración de Sistemas de Información no se limita a la gestión técnica de infraestructuras o aplicaciones, sino que constituye una disciplina estratégica donde confluyen negocio, tecnología y capital humano. El aprendizaje central radica en asumir que los sistemas de información funcionan dentro de organizaciones complejas, y que su éxito depende tanto de decisiones estratégicas como de la gestión adecuada de las personas.

El análisis de los distintos modelos organizacionales mostré que la estructura de TI influye en la capacidad de respuesta ante el cambio, la innovación y la competitividad.

Asimismo, el estudio del Strategic Alignment Model reforz6 la importancia de la alineación entre estrategia empresarial y estrategia tecnológica, evidenciando que IT no debe actuar de manera aislada, sino como un habilitador estratégico del negocio.

La gestión integral del capital humano aparecid como un pilar esencial en organizaciones intensivas en conocimiento. Reclutar perfiles adecuados, desarrollar competencias, retener talento y evaluar desempeño no son tareas exclusivamente administrativas, sino decisiones estratégicas que impactan directamente en la sostenibilidad tecnológica y competitiva.

El abordaje de las teorías motivacionales permitié comprender que el rendimiento en entornos IT depende en gran medida de factores como autonomia, proposito, aprendizaje continuo y reconocimiento. En este sentido, los aportes de Abraham Maslow, Frederick Herzberg y Daniel Pink ayudan a interpretar por qué los profesionales tecnológicos valoran desafios significativos y oportunidades de crecimiento más alla de la compensación econdmica.

También se incorporaron herramientas como el FODA, la gestión por competencias, el coaching tecnológico y el autoconocimiento, reforzando la idea de que el desarrollo profesional del ingeniero en sistemas requiere tanto capacidades técnicas como habilidades estratégicas y humanas.

En conclusión, esta unidad sienta las bases para una formación integral. El ingeniero que internalice estos conceptos estara mejor preparado para integrarse en equipos interdisciplinarios, comprender decisiones estratégicas, participar en procesos de transformación digital y proyectar una carrera que combine excelencia técnica con liderazgo organizacional.

La Dirección de Talento y Capital Humano no es un complemento accesorio de la ingenieria en sistemas: es un componente esencial para generar valor sostenible en la economia digital actual.
